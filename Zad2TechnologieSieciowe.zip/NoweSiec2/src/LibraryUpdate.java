import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class LibraryUpdate {

    public void update(Book book, long bookId, Connection connection) {
        final String sql = "update books set bookTitle=?, bookAuthor=?, bookYear=?, bookISBN=? where id = ?";
        try {
            PreparedStatement prepStmt = connection.prepareStatement(sql);
            prepStmt.setString(1, book.getBookTitle());
            prepStmt.setString(2, book.getBookAuthor());
            prepStmt.setString(3, book.getBookYear());
            prepStmt.setString(4, book.getBookISBN());
            prepStmt.setLong(5, bookId);
            prepStmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Could not update record");
        }
    }

}
