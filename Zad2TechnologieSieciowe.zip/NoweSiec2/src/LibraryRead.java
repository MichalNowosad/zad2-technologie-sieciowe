import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LibraryRead {

    public Book read(long bookId, Connection connection) {
        final String sql = "select bookId, bookTitle, bookAuthor, bookYear, bookISBN from books where id = ?";
        try {
            PreparedStatement prepStmt = connection.prepareStatement(sql);
            prepStmt.setLong(1, bookId);
            ResultSet result = prepStmt.executeQuery();
            if (result.next()) {
                Book book = new Book();
                book.setId(result.getInt("id"));
                book.setBookTitle(result.getString("firstName"));
                book.setBookAuthor(result.getString("lastName"));
                book.setBookYear(result.getString("bookYear"));
                book.setBookISBN(result.getString("bookISBN"));
                return book;
            }
        } catch (SQLException e) {
            System.out.println("Could not get employee");
        }
        return null;
// lub ElementNotFoundException
    }

}

