import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class LibrarySave {

    public void save(Book book, Connection connection) {
        final String sql = "insert into books(bookId, bookTitle, bookAuthor, bookYear, bookISBN) values(?, ?, ?, ?, ?)";
        try {
            PreparedStatement prepStmt = connection.prepareStatement(sql);
            prepStmt.setString(1, book.getBookTitle());
            prepStmt.setString(2, book.getBookAuthor());
            prepStmt.setString(3, book.getBookYear());
            prepStmt.setString(4, book.getBookISBN());
            prepStmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Could not save record");
            e.printStackTrace();
        }
    }

}