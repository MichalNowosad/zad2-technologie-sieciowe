import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class BookDao {

    private static final String URL = "jdbc:mysql://localhost:3306/library";
    private static final String USER = "root";
    private static final String PASS = "admin";
    private static Connection connection;

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASS);
        } catch (ClassNotFoundException e) {
            System.out.println("No driver found");
        } catch (SQLException e) {
            System.out.println("Could not establish connection");
        }

        Scanner keyboard = new Scanner(System.in);
        String input;

        while (true) {
            System.out.println("Wybierz opcję:");
            System.out.println("1 - Dodaj nowy rekord");
            System.out.println("2 - Wyświetl wszystkie książki");
            System.out.println("3 - Usuwanie");
            System.out.println("4 - Aktualizacja");

            input = keyboard.nextLine();

            if (input.equals("1")) {

                System.out.println("Podaj Tytuł");
                String bookTitle = keyboard.nextLine();
                System.out.println("Podaj Autora");
                String bookAuthor = keyboard.nextLine();
                System.out.println("Podaj Rok");
                String bookYear = keyboard.nextLine();
                System.out.println("Podaj ISBN");
                String bookISBN = keyboard.nextLine();

                Book book = new Book(bookTitle, bookAuthor, bookYear, bookISBN);

                LibrarySave librarySave = new LibrarySave();
                librarySave.save(book, connection);
            } else if (input.equals("2")) {
                System.out.println("Podaj Id Książki");
                int bookId = keyboard.nextInt();

                LibraryRead libraryRead = new LibraryRead();
                libraryRead.read(bookId, connection);
            } else if (input.equals("3")) {

                System.out.println("Podaj Id Książki, której dane chcesz zmienić");
                int bookId = keyboard.nextInt();
                System.out.println("Podaj Tytuł");
                String bookTitle = keyboard.nextLine();
                System.out.println("Podaj Autora");
                String bookAuthor = keyboard.nextLine();
                System.out.println("Podaj Rok");
                String bookYear = keyboard.nextLine();
                System.out.println("Podaj ISBN");
                String bookISBN = keyboard.nextLine();

                Book book = new Book(bookTitle, bookAuthor, bookYear, bookISBN);

                LibraryUpdate libraryUpdate = new LibraryUpdate();
                libraryUpdate.update(book, bookId, connection);
            } else if (input.equals("4")) {
                System.out.println("Podaj Id Książki, którą chcesz usunąć");
                int bookId = keyboard.nextInt();

                LibraryDelete libraryDelete = new LibraryDelete();
                libraryDelete.delete(bookId, connection);
            } else
                break;

        }

        close();

        }


    public static void close() {
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}